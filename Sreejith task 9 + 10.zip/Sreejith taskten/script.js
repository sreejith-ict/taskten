
// This function is check if Password and Confirm Password are same

document.addEventListener("DOMContentLoaded", function() {
    const pass1Field = document.getElementById("pass1");
    const passField = document.getElementById("pass");
    const form = document.querySelector("form");

    function checkPasswords() {
        const password = passField.value;
        const confirmPassword = pass1Field.value;

        if (password === confirmPassword) {
            pass1Field.style.border = "3px solid green";
            pass1Field.style.boxShadow = "0 0 10px green";
            pass1Field.style.boxShadow = "inset 0 0 5px green";
            return true;
        } else {
            pass1Field.style.border = "3px solid red";
            pass1Field.style.boxShadow = "0 0 5px red";
            pass1Field.style.boxShadow = "inset 0 0 5px red";
            return false;
        }
    }

    // Check passwords on input

    passField.addEventListener("input", checkPasswords);
    pass1Field.addEventListener("input", checkPasswords);

    // Prevent form submission if passwords don't match

    form.addEventListener("submit", function(event) {
        if (!checkPasswords()) {
            event.preventDefault();
            alert("Passwords do not match.");
        }
        else{
            alert("You've been registered. Please check your email for details box!");
        }
    });
});

// This section is for dissappearing the image when the mouse hovers

document.addEventListener('DOMContentLoaded', () => {
    const image = document.getElementById('hover-image');

    image.addEventListener('mouseout', () => {
        image.style.opacity = '1'; // Show the image when not hovering
    });

    image.addEventListener('mouseover', () => {
        image.style.opacity = '0'; // Hide the image on hover
    });
});

// This section is for the show password function

function showPassword(fieldId, checkbox) {
    var passwordField = document.getElementById(fieldId);
    if (checkbox.checked) {
        passwordField.type = "text";
    }
    else {
        passwordField.type = "password";
    }
}
